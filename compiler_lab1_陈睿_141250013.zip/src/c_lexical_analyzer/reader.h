//
// Created by RayChen on 2016/10/24.
//

#ifndef TEST2_READER_H
#define TEST2_READER_H

#include <string>

std::string readFile(std::string fileName);

#endif //TEST2_READER_H
